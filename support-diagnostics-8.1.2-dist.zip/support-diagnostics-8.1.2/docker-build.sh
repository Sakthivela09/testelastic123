#!/usr/bin/env bash

docker build -f ./docker/Dockerfile -t support-diagnostics-app .
